<?php
$lang['wechat_binding_register_title']		= '完善账号信息';
$lang['wechat_binding_was_successful']	 			= '微信绑定成功';
$lang['wechat_binding_was_failed']	 			= '微信登录失败';

//提示性文字
$lang['home_wx_prompt_1']			= '您使用微信账号';
$lang['home_wx_prompt_2']			= '第一次登录，请选择注册新账号也可绑定已有账号，后期可直接登录';

return $lang;