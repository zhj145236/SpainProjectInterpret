<?php
//index
$lang['standing_im']				= '站内IM';

return $lang;