<?php
/**
 * index
 */
$lang['promotion_prompt_words1']	= '努力加载中...';
$lang['promotion_prompt_words2']	= '没有记录了';

/**
 * item
 */
$lang['sale_price']	= '促销价';
$lang['direct_fall']	= '直降';
$lang['immediate_rush']	= '立即抢购';
$lang['article_classification']	= '文章分类';

//controller
$lang['limited_time_discount']	= '限时折扣';

return $lang;