<?php
$lang['link'] = '友情链接';
$lang['link_prompt_words_1'] = '申请友情链接请发邮箱';
$lang['link_prompt_words_2'] = '，注明：友情链接。';


return $lang;
?>
