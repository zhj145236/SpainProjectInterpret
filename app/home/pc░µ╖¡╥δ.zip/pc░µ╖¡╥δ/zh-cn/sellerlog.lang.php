<?php
//seller_log
$lang['sellerlog_account'] = '账号';
$lang['sellerlog_log_content'] = '日志内容';
$lang['sellerlog_time'] = '时间';
$lang['sellerlog_success'] = '成功';
$lang['sellerlog_failure'] = '失败';

return $lang;