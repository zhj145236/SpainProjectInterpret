<?php
$lang['bonus_not_begin'] = '活动红包未开始';
$lang['bonus_type_error'] = '不是活动红包不能直接领取';
$lang['bonus_expire'] = '活动红包已过期';
$lang['bonus_invalid'] = '活动红包已失效';
$lang['bonusreceive_info'] = '您在%s已领取过此活动红包,领取的金额是:%s';
$lang['bonus_send_over'] = '活动红包已领完';
$lang['receive_bonus'] = '领取活动红包';
$lang['get_bonus_info'] = '获得%s元红包';

return $lang;
?>
