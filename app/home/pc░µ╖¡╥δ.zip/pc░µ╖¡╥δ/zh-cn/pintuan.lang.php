<?php

$lang['pintuan_list'] = '拼团列表';
$lang['pintuan_no_record'] = '最近没有拼团活动';

return $lang;