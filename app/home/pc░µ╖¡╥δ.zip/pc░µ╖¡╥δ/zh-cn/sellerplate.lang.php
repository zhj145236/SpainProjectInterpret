<?php
//plate_add
$lang['format_name']		= '版式名称';
$lang['format_name_description']		= '请输入10个字符内的名称，方便商品发布 / 编辑时选择使用。';
$lang['layout_position']		= '版式位置';
$lang['top']		= '顶部';
$lang['bottom']		= '底部';
$lang['insert_description']		= '选择关联版式插入到页面中的位置，选择“顶部”为商品详情上方内容，“底部”为商品详情下方内容。';
$lang['format_content']		= '版式内容';
$lang['insert_photo_album']		= '插入相册图片';
$lang['close_album']		= '关闭相册';
$lang['fill_format_name']		= '请填写版式名称';
$lang['format_name_limit']		= '版式名称不能超过10个字符';
$lang['fill_format_content']		= '请填写版式内容';

//plate_list
$lang['add_association_format']		= '添加关联版式';
$lang['action_prompt']		= '操作提示';
$lang['action_prompt_instruction']		= '1、关联版式可以把预设内容插入到商品描述的顶部或者底部，方便商家对商品描述批量添加或修改。';

return $lang;

