<?php
/**
 * chat_log
 */
$lang['customer_service'] = '客服';
$lang['members'] = '会员';
/**
 * chat_user
 */
$lang['with'] = '与';
$lang['last_dialogue_time'] = '的最后对话时间';
/**
 * chat_log
 */
$lang['can_only_query'] = '只能查询';
$lang['to'] = '到';
$lang['customer_service_dialogue_member'] = '”的聊天记录，切换不同的选项卡选择可查看与店铺客服最近对话的会员。';
$lang['last_contact'] = '最近联系人';
$lang['keyword'] = '关键字';
$lang['commencement_date'] = '起止日期';
$lang['query'] = '查询';
$lang['queries_within_time_period'] = '从左侧对话列表中选择会员显示聊天记录，使用“起止日期”进行时间段内的查询';

//controller
$lang['chat_query'] = '聊天记录查询';

return $lang;