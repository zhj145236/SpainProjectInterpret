<?php
$lang['bargain_not_exist'] = '砍价活动不存在';
$lang['bargain_list'] = '砍价列表';
$lang['bargain_no_record'] = '最近没有砍价活动';

return $lang;
