<?php
$lang['store_picture_no_video'] = '暂无视频';
$lang['store_video_upload'] = '上传视频';
$lang['store_video_delete'] = '删除视频';
$lang['store_video_delete_confirm_message'] = "您确定进行该操作吗?\\n注意：使用中的视频也将被删除";
return $lang;


?>
