<?php
$lang['bargain_not_exist'] = '砍价活动不存在';
$lang['bargain_already_add'] = '您已经添加过该砍价活动';
$lang['bargain_self'] = '不能帮自己砍';
$lang['bargain_repeat'] = '不能重复砍';
$lang['bargain_fail'] = '砍价失败';
$lang['bargain_log_add_fail'] = '新增砍价记录失败';
$lang['bargain_add_self'] = '不能设置自己的商品参加砍价';
return $lang;
?>
