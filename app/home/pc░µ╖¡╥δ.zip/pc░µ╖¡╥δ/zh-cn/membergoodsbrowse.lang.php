<?php
/**
 *  index
 */
$lang['clear_all_footprints']	= '清空全部足迹';
$lang['mall_price']		= '商城价';
$lang['add_cart']	= '加入购物车';
$lang['delete_record']		= '删除该记录';
$lang['market_price']		= '市场价';

//controller
$lang['today']		= '今天';
$lang['yesterday']		= '昨天';
$lang['my_footprint']		= '我的足迹';

return $lang;
?>