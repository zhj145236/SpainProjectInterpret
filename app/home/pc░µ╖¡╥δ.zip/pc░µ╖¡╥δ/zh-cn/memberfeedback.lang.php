<?php
$lang['feedback_list'] = '反馈列表';
$lang['feedback_add'] = '提交反馈';
$lang['memberfeedback_content'] = '反馈内容';
$lang['memberfeedback_content_tip'] = '反馈内容不能为空';
$lang['memberfeedback_time'] = '反馈时间';


return $lang;
?>
