<?php
$lang['memberbank_type'] = '账户类型';
$lang['memberbank_truename'] = '开户名';
$lang['memberbank_name'] = '开户行';
$lang['memberbank_no'] = '账号';

$lang['please_fill_memberbank_truename'] = '请填写开户名';
$lang['please_fill_memberbank_no'] = '请填写账号';
$lang['memberbank_does_not_exist'] = '提现账号不存在';

$lang['memberbank_index'] = '我的提现账户';
$lang['memberbank_add'] = '添加提现账户';
$lang['memberbank_edit'] = '编辑提现账户';

return $lang;
