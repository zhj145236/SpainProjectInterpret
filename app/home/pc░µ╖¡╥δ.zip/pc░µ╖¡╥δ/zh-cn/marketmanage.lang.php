<?php
$lang['bargain_not_exist'] = '砍价活动不存在';
$lang['market_activity_not_exist'] = '活动不存在';

$lang['market_activity_not_begin'] = '活动未开始';
$lang['market_activity_not_end'] = '活动已结束';
$lang['market_award_set_error'] = '奖项设置错误';
$lang['bonus_set_error'] = '红包设置错误';
$lang['bonus_fixedprice_notice'] = '元红包';
$lang['bonus_randomprice_notice'] = '元随机红包';
$lang['vouchertemplate_notice'] = '元代金券';
$lang['marketmanage_jointype_set_error'] = '活动参与类型设置错误';
$lang['marketmanage_joincount_error'] = '您已经参与%s次了，请下次再来';

$lang['market_1'] = '刮刮卡';
$lang['market_2'] = '幸运大抽奖';
$lang['market_3'] = '幸运砸金蛋';
$lang['market_4'] = '生肖翻翻看';
return $lang;
?>
