<?php

/**
 * 共有语言
 */
$lang['inviterpro_no_record'] = '没有找到符合条件的商品';
$lang['inviterpro_most_inviter_amount'] = '最高赚';
$lang['inviterpro_inviter_market'] = '分销市场';
$lang['category_filtering'] = '分类筛选';
$lang['product_screening'] = '商品筛选';

return $lang;
?>
