<?php
$lang['comparison_basic_information']	 			= '基本信息对比';
$lang['to_contrast']	 			= '开始对比';
$lang['no_comparison_term']	 			= '暂无对比项';
$lang['compare_delete']	 			= '删除';
$lang['compare_add']	 			= '添加';
$lang['compare_empty']	 			= '清空';
$lang['uncorrelated_goods']	 			= '对比栏暂无对比商品，先添加对比商品再来进行详细比较吧！';
$lang['highlight_different_items']	 			= '高亮显示不同项';
$lang['unhighlight_different_items']	 			= '取消高亮不同项';
$lang['hide_same_item']	 			= '隐藏相同项';
$lang['show_same_item']	 			= '显示相同项';
$lang['empty_contrast_bar']	 			= '清空对比栏';

$lang['commodity_picture']		= '商品图片';
$lang['commodity_price']		= '商城价';
$lang['brand']		= '所属品牌';
$lang['location']		= '所在地';
$lang['vat_invoice']		= '是否开增值税发票';
$lang['comparison_bar_full']		= '对比栏已满，您可以删除不需要的栏内商品再继续添加哦！';

return $lang;
