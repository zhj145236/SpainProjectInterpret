<?php
$lang['proprietary']		= '自营';
$lang['the_phone']		= '电话';
$lang['address']		= '地址';
$lang['in_the_search']		= '搜索中...';
$lang['no_shops']		= '抱歉！您当前位置周边2KM内暂时还没有相关的店铺。';
$lang['your_city']		= '抱请选择您所在的城市';
$lang['in_the_location']		= '定位中...';
$lang['office_building']		= '小区、写字楼、学校';
$lang['all_categories']		= '全部分类';

//controller
$lang['store_doesn_fill_area']		= '店铺未填区域';
$lang['store_not_filled_detailed_address']		= '店铺未填详细地址';

return $lang;



?>