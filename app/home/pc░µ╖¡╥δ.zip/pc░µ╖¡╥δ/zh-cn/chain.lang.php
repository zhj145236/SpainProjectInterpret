<?php
$lang['password_not_same'] = '密码不一致';
$lang['wait_for_verify'] = '操作成功，等待管理员审核';
$lang['old_password_wrong'] = '原密码填写错误';
$lang['order_not_exist'] = '订单不存在';
$lang['pickup_code_error'] = '提货码错误';
$lang['chain'] = '门店';
$lang['chain_receive_goods'] = '门店确认收货';

$lang['login_fail'] = '登录失败';
$lang['chain_name_exist'] = '门店用户名已存在';

$lang['goods_not_exist'] = '商品不存在';
return $lang;
?>
