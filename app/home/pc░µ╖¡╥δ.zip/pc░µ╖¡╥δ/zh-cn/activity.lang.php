<?php
$lang['activity_index_activity_not_exists'] = '指定活动并不存在';
$lang['activity_index_goods_price'] = '原价';
$lang['activity_list'] = '活动列表';
$lang['activity_to'] = '至';
$lang['activity_buy_now'] = '立即购买';

return $lang;
?>
