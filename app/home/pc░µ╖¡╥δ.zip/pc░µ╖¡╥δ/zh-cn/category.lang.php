<?php
$lang['category_index_store_class']		= '店铺分类';
$lang['category_index_goods_class']		= '全部商品分类';
$lang['category_index_recommend_store']	= '推荐店铺';
$lang['category_index_store_owner']		= '店主';
$lang['category_index_goods']			= '商品';
$lang['category_index_credit']			= '信用';
$lang['category_index_new_store']		= '最新店铺';
$lang['category_index_store_list']		= '店铺列表';

$lang['category_all_categories']		= '全部分类';
$lang['category_all_brands']		= '全部品牌';
$lang['category_all_products']		= '全部商品';
$lang['category_all_store_categories']		= '全部店铺分类';
$lang['category_all_categories']		= '全部商品分类';

$lang['commodity_picture']		= '商品图片';
$lang['commodity_price']		= '商城价';
$lang['brand']		= '所属品牌';
$lang['location']		= '所在地';
$lang['vat_invoice']		= '是否开增值税发票';
$lang['comparison_bar_full']		= '对比栏已满，您可以删除不需要的栏内商品再继续添加哦！';

return $lang;

