<?php
$lang['member_name_error'] = '接收消息会员账号错误';
$lang['send_fail'] = '发送失败，请稍后重新发送';
$lang['goods_not_exist'] = '商品不存在';

return $lang;
?>
