<?php
/**
 * 列表
 */
$lang['cost_consumption_content']	= '消费内容';
$lang['cost_time']			= '时间';
$lang['cost_consumption_amount']			= '消费金额';
$lang['cost_status']	= '状态';
$lang['cost_settled']			= '已结算';
$lang['cost_not_settled']			= '未结算';
$lang['cost_list']			= '消费列表';

return $lang;