<?php
//login
$lang['business_name_application'] = '请输入您注册商铺时申请的商家名称';
$lang['universal_password_mall_users'] = '登录密码为商城用户通用密码';
$lang['sellerlogin_password'] = '密码';
$lang['return_home_page'] = '返回首页';

$lang['password_error'] = '用户名密码错误';
$lang['seller_account_not_exisit'] = '卖家账户不存在';

return $lang;