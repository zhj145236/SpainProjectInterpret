<?php
/**
 * activity_apply
 */
$lang['activity_apply_price'] = "售价";
$lang['choose_products_event'] = "选择参加活动的商品，勾选并提交平台审核";
$lang['search_product_names'] = "搜索商品名称";
$lang['sales_price'] = "销售价格";

return $lang;
