<?php

$lang['user_not_exist']				= '用户不存在';
$lang['already_login']				= '已经登录';
$lang['xcx_not_set']				= '未配置小程序';
$lang['wechat_not_set']				= '未配置微信';
$lang['error_code']				= '错误码';
$lang['openid_not_get']				= '未获得微信用户授权';
$lang['unionid_not_get']				= '获取unionid失败';
$lang['register_fail']				= '用户注册失败';

return $lang;