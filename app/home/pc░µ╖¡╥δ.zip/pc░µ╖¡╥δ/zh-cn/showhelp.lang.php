<?php
$lang['update_time'] = '更新时间';
$lang['platform_contact']		= '平台联系方式';
$lang['phone']		= '电话';
$lang['email']		= '邮箱';

return $lang;

?>