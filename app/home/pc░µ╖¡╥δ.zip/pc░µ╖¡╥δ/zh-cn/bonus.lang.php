<?php
$lang['bonus_not_exist'] = '活动红包不存在';


return $lang;
?>
