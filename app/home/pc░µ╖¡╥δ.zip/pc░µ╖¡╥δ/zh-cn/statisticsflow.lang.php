<?php

/**
 * flowgoods
 */
$lang['store_merchandise']			= '1、统计图展示了在搜索时间段内访问次数多的店铺商品前30名';
$lang['with_week_statistics']			= '按照周统计';
$lang['with_monthly_statistics']			= '按照月统计';

/**
 * index
 */
$lang['traffic_trends']			= '1、统计图展示了店铺在搜索时间段内的访问量走势情况';

//controller
$lang['traffic'] = '访问量';
$lang['store_traffic_statistics'] = '店铺访问量统计';
$lang['visits'] = '访问次数';
$lang['product_visits'] = '商品访问量TOP30';
$lang['total_store_flow'] = '店铺总流量';
$lang['commodity_flow_ranking'] = '商品流量排名';

return $lang;