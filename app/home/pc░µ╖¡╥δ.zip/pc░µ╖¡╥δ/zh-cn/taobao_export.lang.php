<?php
$lang['zip_create_fail']		='压缩文件创建失败';

return $lang;



?>