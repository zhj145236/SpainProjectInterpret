<?php
$lang['arrivalnotice_arrivalnotice'] = '到货通知';
$lang['arrivalnotice_goods_name']		= '商品名称';
$lang['arrivalnotice_member_name']		= '会员用户名';
$lang['arrivalnotice_mobile']		= '手机';
$lang['arrivalnotice_state']		= '通知状态';
$lang['arrivalnotice_addtime']		= '登记时间';
$lang['arrivalnotice_time']		= '通知时间';
$lang['arrivalnotice_noinformed']		= '未通知';
$lang['arrivalnotice_informed']		= '已通知';

return $lang;