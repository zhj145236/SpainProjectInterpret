<?php
$lang['ds_member_chat_login']	=  '登录超时或者当前账号已退出';
$lang['ds_member_chat_name_error']	=  '接收消息会员账号错误';
$lang['ds_member_chat_add_error']	=  '发送失败，请稍后重新发送';

return $lang;
